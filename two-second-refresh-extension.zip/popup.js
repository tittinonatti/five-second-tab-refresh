const status = document.querySelector("#status");
const toggle = document.querySelector("#toggle");

function render(enabled) {
  status.textContent = enabled ? "自動更新中（2秒）" : "停止中";
  toggle.textContent = enabled ? "停止" : "開始";
  toggle.dataset.enabled = String(enabled);
}

chrome.runtime.sendMessage({ type: "getEnabled" }, (response) => {
  render(response?.enabled !== false);
});

toggle.addEventListener("click", () => {
  const enabled = toggle.dataset.enabled !== "true";
  chrome.runtime.sendMessage({ type: "setEnabled", enabled }, () => {
    render(enabled);
  });
});
