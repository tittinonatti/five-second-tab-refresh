(() => {
  const intervalName = "__fiveSecondAutoRefresh";

  function stopRefresh() {
    if (window[intervalName]) {
      window.clearInterval(window[intervalName]);
      window[intervalName] = null;
    }
  }

  function startRefresh() {
    stopRefresh();
    window[intervalName] = window.setInterval(() => {
      window.location.reload();
    }, 5000);
  }

  chrome.storage.local.get("enabled").then((state) => {
    if (state.enabled !== false) startRefresh();
  });

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local" || !changes.enabled) return;

    if (changes.enabled.newValue === true) {
      startRefresh();
    } else {
      stopRefresh();
    }
  });
})();
