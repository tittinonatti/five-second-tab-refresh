async function configureEnabled(enabled) {
  await chrome.storage.local.set({ enabled });
}

chrome.runtime.onStartup.addListener(async () => {
  const state = await chrome.storage.local.get("enabled");
  await configureEnabled(state.enabled === true);
});

chrome.runtime.onInstalled.addListener(async () => {
  const state = await chrome.storage.local.get("enabled");
  await configureEnabled(state.enabled !== false);
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "setEnabled") {
    configureEnabled(message.enabled).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (message.type === "getEnabled") {
    chrome.storage.local.get("enabled").then((state) => {
      sendResponse({ enabled: state.enabled === true });
    });
    return true;
  }
});

